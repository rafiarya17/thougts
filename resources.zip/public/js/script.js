alert("Hello Selamat Datang di Haltev IT Learning Center");
