<!-- apapun yg ada di dalam section akan masuk menggantikan yield selama di halaman home ini mengambil / menggunakan layouts main.blade.php | cara menulisnya relative terhadap folder views -->


<!-- tulisan ini adalah sebuah section yg bernama 'container' -->
<?php $__env->startSection('container'); ?>
    <h1>Halaman Home</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel-project\haltev-blog-3\resources\views/home.blade.php ENDPATH**/ ?>