

<?php $__env->startSection('container'); ?>
<article>
    <h2> <?php echo e($post->title); ?> </h2>
    <p>By. <a href="#" class="text-decoration-none"> <?php echo e($post->user->name); ?> </a> in <a href="/categories/<?php echo e($post->category->slug); ?>"> <?php echo e($post->category->name); ?> </a> </p>

    <!-- agar inputan (jika dalam bentuk html maka kita panggila variabelnya jangan di escape) -->
    <?php echo $post->body; ?>

</article>

<a href="/blog"><< Kembali ke halaman Blog</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel-project\haltev-blog-Dashboard\resources\views/post.blade.php ENDPATH**/ ?>