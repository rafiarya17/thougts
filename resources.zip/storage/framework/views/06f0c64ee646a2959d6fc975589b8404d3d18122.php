

<?php $__env->startSection('container'); ?>
<article>
    <h2> <?php echo e($post->title); ?> </h2>
    <h5 class="mt-5">By. Willy Hihola in <a href="/categories/<?php echo e($post->category->slug); ?>"><?php echo e($post->category->name); ?></a> </h5>

    <!-- agar inputan (jika dalam bentuk html maka kita panggila variabelnya jangan di escape) -->
    <?php echo $post->body; ?>

</article>

<a href="/blog"><< Kembali ke halaman Blog</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel-project\haltev-blog-3\resources\views/post.blade.php ENDPATH**/ ?>